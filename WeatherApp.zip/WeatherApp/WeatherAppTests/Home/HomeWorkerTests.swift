//
//  HomeWorkerTests.swift
//  WeatherAppTests
//
//  Created by Nikhil Nandha on 03/12/21.
//

import XCTest
import OHHTTPStubs
import CoreData
@testable import WeatherApp
 
class HomeWorkerTests: XCTestCase {
    
    var homeWorker: HomeWorker!

    override func setUpWithError() throws {
        homeWorker = HomeWorker(persistentContainer: TestCoreDataStack().persistentContainer)
        stub(condition: isHost("us-central1-mobile-assignment-server.cloudfunctions.net")) { _ in
          // Stub it with our "wsresponse.json" stub file (which is in same bundle as self)
          let stubPath = OHPathForFile("homeworker.json", type(of: self))
          return fixture(filePath: stubPath!, headers: ["Content-Type":"application/json"])
        }
    }
    

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        homeWorker = nil
    }

    func test_fetchWeatherData() {
        var error: NetworkError?
        var weatherResponse: [HomeModel.WeatherModel]?
        let expectation = self.expectation(description: "WeatherAPICall")
        homeWorker.fetchWeatherDataFromServer { result in
            expectation.fulfill()
            switch result {
            case .success(let responseData):
                weatherResponse = responseData
            case .failure(let networkError):
                error = networkError
            }
        }
        waitForExpectations(timeout: 5, handler: nil)
        XCTAssertNotNil(weatherResponse?.first?.city)
        XCTAssertNotNil(weatherResponse?.first?.temp)
        XCTAssertNotNil(weatherResponse?.first?.tempType)
        XCTAssertNotNil(weatherResponse?.first?.date)
        XCTAssertNil(error)
        
        let dataSynced = homeWorker.syncWeatherData(weatherList: weatherResponse ?? [HomeModel.WeatherModel](), taskContext: TestCoreDataStack().persistentContainer.newBackgroundContext())
        XCTAssertTrue(dataSynced, "Core data tests sync success")
    }
    
    func test_fetchWeatherCoreDataEntites() {
        let results = homeWorker.fetchWeatherCoreDataEntites()
        XCTAssertNotNil(results)
    }

}

class TestCoreDataStack: NSObject {
    
    lazy var persistentContainer: NSPersistentContainer = {
        let description = NSPersistentStoreDescription()
        description.url = URL(fileURLWithPath: "/dev/null")
        let container = NSPersistentContainer(name: "WeatherApp")
        container.persistentStoreDescriptions = [description]
        container.loadPersistentStores { _, error in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }
        return container
    }()
}
