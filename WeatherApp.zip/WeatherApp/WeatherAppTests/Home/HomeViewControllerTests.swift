//
//  HomeViewControllerTests.swift
//  WeatherAppTests
//
//  Created by Nikhil Nandha on 03/12/21.
//

import XCTest
@testable import WeatherApp

class HomeBusinessLogincStub: HomeBusinessLogic {
    func fetchWeatherData() {
    }
}

class HomeViewControllerTests: XCTestCase {
    
    var homeBusinessLogic: HomeBusinessLogic!
    var homeViewController: HomeViewController!

    override func setUpWithError() throws {
        homeBusinessLogic = HomeBusinessLogincStub()
        let yourStoryboard = UIStoryboard(name: "Main", bundle: nil)
        homeViewController = (yourStoryboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController)
        homeViewController.loadView()
        homeViewController.viewDidLoad()
        homeViewController.interator = homeBusinessLogic
    }

    override func tearDownWithError() throws {
        homeViewController = nil
        homeBusinessLogic = nil
    }
    
    func test_initWithCoder() throws {
        guard let data = try? NSKeyedArchiver.archivedData(withRootObject: homeViewController.view!, requiringSecureCoding: true) else { return }
        let coder = try NSKeyedUnarchiver(forReadingFrom: data)
        let sut = HomeViewController(coder: coder)
        XCTAssertNotNil(sut)
    }
    
    func test_initWithNibName() {
        
    }
    
    func test_refresh() {
        homeViewController.refresh(homeViewController.refreshControl)
    }
    
    func test_tableViewCellforRowAtIndexPath() {
        let cell = homeViewController.tableView(homeViewController.tableV, cellForRowAt: IndexPath(row: 0, section: 0))
        XCTAssertNotNil(cell)
    }
    
    func test_tableViewNumberOfRow() {
        let row = homeViewController.tableView(homeViewController.tableV, numberOfRowsInSection: 0)
        XCTAssertEqual(row, 0, accuracy: 1)
    }
    
    func test_tableViewDidSelectRowAtIndexPath() {
        homeViewController.tableView(homeViewController.tableV, didSelectRowAt: IndexPath(row: 0, section: 0))
    }
    
//    func test_fetchedResults() {
//        homeViewController.fetchedResults(nil, cities: nil, error: NetworkError.noInternetError)
//    }
    
}
