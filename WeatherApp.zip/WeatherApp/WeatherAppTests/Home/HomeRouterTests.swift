//
//  HomeRouterTests.swift
//  WeatherAppTests
//
//  Created by Nikhil Nandha on 04/12/21.
//

import XCTest
@testable import WeatherApp

class HomeRouterTests: XCTestCase {

    var homeRouter: HomeRouter!
    
    override func setUpWithError() throws {
        homeRouter = HomeRouter()
        let yourStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let homeViewController = (yourStoryboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController)
        homeRouter.viewController = homeViewController
    }

    override func tearDownWithError() throws {
        homeRouter = nil
    }
    
    func test_routeToDetailsScreen() {
        let data: [HomeModel.WeatherModel]? = HomeRouterTests.load("homeworker", bundle: Bundle(for: type(of: self)))
        homeRouter.routeToDetailsScreen(cityData: data?.first, weatherData: data)
    }

    func test_filteredWeatherCityData() {
        let data: [HomeModel.WeatherModel]? = HomeRouterTests.load("homeworker", bundle: Bundle(for: type(of: self)))
        let filteredData = homeRouter.filteredWeatherCityData(cityData: data?.first, weatherData: data)
        XCTAssertNotNil(filteredData)
    }
    
    class func load<T: Decodable>(_ filename: String, bundle: Bundle?) -> T? {
        let data: Data
        guard let file = bundle?.url(forResource: filename, withExtension: "json") else {
            XCTFail("Missing file: \(filename).json")
            return nil
        }

        do {
            data = try Data(contentsOf: file)
        } catch {
            XCTFail("Content is not valid")
            return nil
        }

        do {
            let decoder = JSONDecoder()
            return try decoder.decode(T.self, from: data)
        } catch {
            XCTFail("Couldn't parse \(filename) as \(T.self):\n\(error)")
            return nil
        }
    }
}
