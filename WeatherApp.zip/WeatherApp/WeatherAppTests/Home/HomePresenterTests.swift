//
//  HomePresenterTests.swift
//  WeatherAppTests
//
//  Created by Nikhil Nandha on 04/12/21.
//

import XCTest
@testable import WeatherApp

class HomePresenterTests: XCTestCase {

    var homePresenter: HomePresenter!
    
    override func setUpWithError() throws {
        homePresenter = HomePresenter()
        let yourStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let homeViewController = (yourStoryboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController)
        homePresenter.viewController = homeViewController
    }

    override func tearDownWithError() throws {
        homePresenter = nil
    }
    
    func test_presentFetchResults() {
        homePresenter.presentFetchResults(nil, cities: nil, error: NetworkError.noInternetError)
    }

}
