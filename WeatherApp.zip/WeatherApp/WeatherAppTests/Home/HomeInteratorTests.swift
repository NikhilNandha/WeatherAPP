//
//  HomeInteratorTests.swift
//  WeatherAppTests
//
//  Created by Nikhil Nandha on 04/12/21.
//

import XCTest
@testable import WeatherApp

class HomeWorkerDataSourceStub: HomeWorkerDataSource {
    func fetchWeatherData(complition: @escaping ([HomeModel.WeatherModel]?, NetworkError?) -> Void) { 
    }
}

class HomeInteratorTests: XCTestCase {

    var homeWorkerDataSourceStub: HomeWorkerDataSourceStub!
    var homeInterator: HomeInterator!
    
    override func setUpWithError() throws {
        homeWorkerDataSourceStub = HomeWorkerDataSourceStub()
        homeInterator = HomeInterator()
        homeInterator.worker = homeWorkerDataSourceStub
    }

    override func tearDownWithError() throws {
        homeWorkerDataSourceStub = nil
    }
    
    func test_fetchedWeatherData() throws {
        homeInterator.fetchWeatherData()
    }
}
