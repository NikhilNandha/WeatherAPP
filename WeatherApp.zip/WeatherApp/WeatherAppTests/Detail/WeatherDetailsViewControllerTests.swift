//
//  WeatherDetailsViewControllerTests.swift
//  WeatherAppTests
//
//  Created by Nikhil Nandha on 04/12/21.
//

import XCTest
@testable import WeatherApp

class WeatherDetailsViewControllerTests: XCTestCase {

    var detailViewController: WeatherDetailViewController!
    var detailInteractor: WeatherDetailInteractor!
    
    override func setUpWithError() throws {
        let yourStoryboard = UIStoryboard(name: "Main", bundle: nil)
        detailViewController = (yourStoryboard.instantiateViewController(withIdentifier: "WeatherDetailViewController") as! WeatherDetailViewController)
        detailViewController.loadView()
        detailViewController.viewDidLoad()
        detailViewController.detailsInterator = WeatherDetailInteractor()
    }

    override func tearDownWithError() throws {
        detailViewController = nil
        detailInteractor = nil
    }

    func test_setupDataOnScreen() {
        let data: [HomeModel.WeatherModel]? = HomeRouterTests.load("homeworker", bundle: Bundle(for: type(of: self)))
        detailViewController.setupDataOnScreen(data: data)
    }
    
    func test_tableViewCellforRowAtIndexPath() {
        let cell = detailViewController.tableView(detailViewController.tableV, cellForRowAt: IndexPath(row: 0, section: 0))
        XCTAssertNotNil(cell)
    }
    
    func test_tableViewNumberOfRow() {
        let row = detailViewController.tableView(detailViewController.tableV, numberOfRowsInSection: 0)
        XCTAssertEqual(row, 0, accuracy: 1)
    }
}
