//
//  WeatherDetailInteratorTests.swift
//  WeatherAppTests
//
//  Created by Nikhil Nandha on 04/12/21.
//

import XCTest
@testable import WeatherApp

class WeatherDetailPresentationLogicStub: WeatherDetailPresentationLogic {
    func presentWeatherDetails(_ data: [HomeModel.WeatherModel]?) {
    }
}

class WeatherDetailInteractorTests: XCTestCase {

    var detailsInteractor: WeatherDetailInteractor!
    var detailsPresenter: WeatherDetailPresentationLogicStub!
    
    override func setUpWithError() throws {
        detailsInteractor = WeatherDetailInteractor()
        detailsInteractor.presenter = detailsPresenter
    }

    override func tearDownWithError() throws {
        detailsInteractor = nil
        detailsPresenter = nil
    }
    
    func test_presentWeatherDetails() {
        let data: [HomeModel.WeatherModel]? = HomeRouterTests.load("homeworker", bundle: Bundle(for: type(of: self)))
        detailsInteractor.presenter?.presentWeatherDetails(data)
    }
    

}
