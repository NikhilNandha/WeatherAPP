//
//  WeatherDetailPresenterTests.swift
//  WeatherAppTests
//
//  Created by Nikhil Nandha on 04/12/21.
//

import XCTest
@testable import WeatherApp

class WeatherDetailPresenterTests: XCTestCase {

    var detailsPresenter: WeatherDetailPresenter!
    
    override func setUpWithError() throws {
        detailsPresenter = WeatherDetailPresenter()
        let yourStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = (yourStoryboard.instantiateViewController(withIdentifier: "WeatherDetailViewController") as! WeatherDetailViewController)
        viewController.loadView()
        detailsPresenter.viewController = viewController
    }

    override func tearDownWithError() throws {
        detailsPresenter = nil
    }
    
    func test_presentWeatherDetails() {
        let data: [HomeModel.WeatherModel]? = HomeRouterTests.load("homeworker", bundle: Bundle(for: type(of: self)))
        detailsPresenter.presentWeatherDetails(data)
    }
}
