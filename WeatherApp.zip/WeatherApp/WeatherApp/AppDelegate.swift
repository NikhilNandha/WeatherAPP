//
//  AppDelegate.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 02/12/21.
//

import UIKit
import CoreData

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        setUpHomeScreen()
        
        return true
    }
    
    func setUpHomeScreen() {
        
        window = UIWindow(frame: UIScreen.main.bounds)
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let navController = storyBoard.instantiateViewController(identifier: "UINaviationController_Home") as! UINavigationController
        navController.navigationBar.barTintColor = UIColor.themeNavigationBarTint
        navController.navigationBar.tintColor = UIColor.themeNavigationTint
        navController.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.themeNavigationTint, NSAttributedString.Key.font : UIFont.systemFont(ofSize: 29)]
        window?.rootViewController = navController
    }
    
}

