//
//  City+CoreDataClass.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 02/12/21.
//

import Foundation
import CoreData

@objc(City)
public class City: NSManagedObject {
    
}
