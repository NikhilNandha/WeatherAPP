//
//  Weather+CoreDataClass.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 02/12/21.
//

import Foundation
import CoreData

@objc(Weather)
public class Weather: NSManagedObject {
    
}
