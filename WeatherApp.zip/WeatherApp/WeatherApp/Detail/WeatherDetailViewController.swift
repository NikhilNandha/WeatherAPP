//
//  WeatherDetailViewController.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 03/12/21.
//

import UIKit

protocol WeatherDetailDisplayLogic: AnyObject {
    func displayWeatherData(_ data: [HomeModel.WeatherModel]?)
}

class WeatherDetailViewController: UIViewController, WeatherDetailDisplayLogic {
   
    @IBOutlet weak var cityNameLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var cityImageView: UIImageView!
    @IBOutlet weak var tableV: UITableView!
    
    var detailsInterator: (WeatherDetailsInteractorLogic & WeatherDetailsDataSource)?
    private var weatherData: [HomeModel.WeatherModel]?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        detailsInterator?.fetchWeatherData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.view.backgroundColor = .clear
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.navigationBar.isTranslucent = false
    }
    
    func displayWeatherData(_ data: [HomeModel.WeatherModel]?) {
        setupDataOnScreen(data: data)
    }

    func setupDataOnScreen(data: [HomeModel.WeatherModel]?) {
        cityNameLabel.text = data?.first?.city?.name
        dateLabel.text = data?.first?.date?.toDate()?.toDetailString()
        if let image = data?.first?.city?.picture {
            cityImageView.loadImage(from: image)
        }
        weatherData = data
        tableV.reloadData()
    }
}

extension WeatherDetailViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return weatherData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailCell", for: indexPath)
        cell.textLabel?.text = weatherData?[indexPath.row].date?.toDate()?.toDetailTimeString()
        cell.detailTextLabel?.text = "\(weatherData?[indexPath.row].celsiusTemp().round(to: 0) ?? 0)°C"
        cell.textLabel?.textColor = UIColor.themeNavigationBarTint
        cell.detailTextLabel?.textColor = UIColor.themeNavigationBarTint
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
}
