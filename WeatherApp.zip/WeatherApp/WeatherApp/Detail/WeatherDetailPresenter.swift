//
//  WeatherDetailPresenter.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 03/12/21.
//

import Foundation

protocol WeatherDetailPresentationLogic {
    func presentWeatherDetails(_ data: [HomeModel.WeatherModel]?)
}

class WeatherDetailPresenter: WeatherDetailPresentationLogic {
    
    weak var viewController: WeatherDetailDisplayLogic?
    
    func presentWeatherDetails(_ data: [HomeModel.WeatherModel]?) {
        viewController?.displayWeatherData(data)
    }
}
