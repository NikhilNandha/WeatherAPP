//
//  WeatherDetailInteractor.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 03/12/21.
//

import Foundation

protocol WeatherDetailsInteractorLogic {
    func fetchWeatherData()
}

protocol WeatherDetailsDataSource {
    var weatherData: [HomeModel.WeatherModel]? { get set }
}

class WeatherDetailInteractor: WeatherDetailsDataSource, WeatherDetailsInteractorLogic {
    
    var weatherData: [HomeModel.WeatherModel]?
    var presenter: WeatherDetailPresentationLogic?
    
    func fetchWeatherData() {
        presenter?.presentWeatherDetails(weatherData)
    }
}
