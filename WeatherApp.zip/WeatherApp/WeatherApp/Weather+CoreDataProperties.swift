//
//  Weather+CoreDataProperties.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 02/12/21.
//

import Foundation
import CoreData

extension Weather {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<Weather> {
        return NSFetchRequest<Weather>(entityName: "Weather")
    }
    
    @NSManaged public var date: Date?
    @NSManaged public var tempType: String?
    @NSManaged public var temp: Double
    @NSManaged public var city: City?
    
    func update(with weather: HomeModel.WeatherModel, context: NSManagedObjectContext) throws {
        self.date = weather.date?.toDate()
        self.tempType = weather.tempType
        self.temp = weather.temp
        
        let cityObj = City(context: context)
        cityObj.name = weather.city?.name
        cityObj.picture = weather.city?.picture
        
        self.city = cityObj
    }

}
