//
//  ServiceManager.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 02/12/21.
//

import Foundation

public enum NetworkError: Error {
    case noInternetError
    case canceledError
    case domainError
    case decodingError
    case badUrl
    case badResponse(code: Int?)
}

class ServiceManager {
    
    static let shared = ServiceManager()
    
    public func loadRequest<T: Codable>(request: URLRequest, completion: @escaping (Result<T, NetworkError>) -> Void)  {
        if !Reachability.isConnectedToNetwork() {
            print("The Internet connection appears to be offline")
            DispatchQueue.main.async {
                completion(.failure(.noInternetError))
            }
            return
        }
        
        let task = getCoreURLSessionTask(request: request, completion: completion)
        task.resume()
    }
    
    private func getCoreURLSessionTask<T: Codable>(
        request: URLRequest,
        completion: @escaping (Result<T, NetworkError>) -> Void
    ) -> URLSessionTask {
        
        let shared = URLSession.init(configuration: .default)
        
        let task = shared.dataTask(with: request) { data, response, error in
            
            if let error = error as NSError?, error.domain == NSURLErrorDomain {
                if error.code == NSURLErrorCancelled {
                    DispatchQueue.main.async {
                        completion(.failure(.canceledError))
                    }
                } else {
                    DispatchQueue.main.async {
                        completion(.failure(.domainError))
                    }
                }
                return
            } else {
                
                if let response = response, !response.isSuccess {
                    DispatchQueue.main.async {
                        completion(.failure(NetworkError.badResponse(code: response.httpStatusCode)))
                    }
                    return
                }
                
                if let data = data {
                    do {
                        let result = try JSONDecoder().decode(T.self, from: data)
                        
                        DispatchQueue.main.async {
                            completion(.success(result))
                        }
                    } catch let error {
                        print("Decoding failed due to: \(error)")
                        DispatchQueue.main.async {
                            completion(.failure(.decodingError))
                        }
                    }
                }
                
            }
        }
        return task
    }
}

extension URLResponse {
    
    var httpStatusCode: Int {
        guard let statusCode = (self as? HTTPURLResponse)?.statusCode else {
            return 0
        }
        return statusCode
    }
    
    var isSuccess: Bool {
        return httpStatusCode >= 200 && httpStatusCode < 300
    }
}


enum Endpoint: String {
    case weather = "/weather"
}

public let ServerUrl = "https://us-central1-mobile-assignment-server.cloudfunctions.net"
