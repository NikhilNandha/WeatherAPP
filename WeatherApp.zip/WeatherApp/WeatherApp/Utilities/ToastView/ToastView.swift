//
//  Toast.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 03/12/21.
//

import UIKit

public enum ToastPosition: Int {
    case top
    case middle
    case bottom
}

public struct ToastViewModal {
    let message: String
    let position: ToastPosition
    let duration: Double
    let controller: UIViewController
    let shouldHideIcon: Bool
    
    public init(withMessage message: String, position: ToastPosition = .top, withDuration: Double = 3.0, controller: UIViewController, shouldHideIcon: Bool = true) {
        self.message = message
        self.position = position
        self.duration = withDuration
        self.controller = controller
        self.shouldHideIcon = shouldHideIcon
    }
}

public class ToastView: UIView {
    
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var imageView: UIImageView!
    
    public override func draw(_ rect: CGRect) {
        super.draw(rect)
        addGradience()
    }
    
    public static func show(toastViewModal: ToastViewModal, isUpperImageHidden: Bool = false, callback: ((Bool) -> Void)? = nil) {
        guard !toastViewModal.message.isEmpty else { return }
        let toastView = Bundle.main.loadNibNamed(String(describing: ToastView.self), owner: self, options: nil)?.first as! ToastView
        toastView.titleLabel.text = toastViewModal.message
        toastView.imageView.isHidden = isUpperImageHidden
        toastView.translatesAutoresizingMaskIntoConstraints = false
        toastView.layoutIfNeeded()
        toastView.tag = 9999
        toastView.alpha = 0.0
        toastView.imageView.isHidden = toastViewModal.shouldHideIcon
        ToastView.removeToast(from: toastViewModal.controller)
        toastViewModal.controller.view.addSubview(toastView)
        setPosition(toastView, toastViewModal.position, toastViewModal.controller)
        toastView.setNeedsDisplay()
        UIView.animate(withDuration: 0.2, animations: {
            toastView.alpha = 1.0
        }, completion: { (_) in
            DispatchQueue.main.asyncAfter(deadline: .now() + toastViewModal.duration) {
                UIView.animate(withDuration: 0.2, animations: {
                    toastView.alpha = 0.0
                }, completion: { (_) in
                    toastView.removeFromSuperview()
                    callback?(true)
                })
            }
        })
    }
    
    public class func removeToast(from controller: UIViewController) {
        if let toastView  = controller.view.viewWithTag(9999) as? ToastView {
            toastView.removeFromSuperview()
        }
    }
    
    private class func setPosition(_ toastView: UIView, _ position: ToastPosition, _ controller: UIViewController) {
        switch position {
        case .top:
            let leading = NSLayoutConstraint(item: toastView, attribute: .leading, relatedBy: .equal, toItem: controller.view, attribute: .leading, multiplier: 1.0, constant: 16)
            let top = NSLayoutConstraint(item: toastView, attribute: .top, relatedBy: .equal, toItem: controller.view.safeAreaLayoutGuide, attribute: .top, multiplier: 1.0, constant: 16)
            let trailing = NSLayoutConstraint(item: toastView, attribute: .trailing, relatedBy: .equal, toItem: controller.view, attribute: .trailing, multiplier: 1.0, constant: -16)
            controller.view.addConstraints([leading, trailing, top])
        case .middle:
            let centerXContraint = NSLayoutConstraint(item: toastView, attribute: .centerX, relatedBy: .equal, toItem: controller.view, attribute: .centerX, multiplier: 1.0, constant: 0)
            let centerYConstraint = NSLayoutConstraint(item: toastView, attribute: .centerY, relatedBy: .equal, toItem: controller.view, attribute: .centerY, multiplier: 1.0, constant: 0)
            let leadingContraint = NSLayoutConstraint(item: toastView, attribute: .trailing, relatedBy: .equal, toItem: controller.view, attribute: .trailing, multiplier: 1.0, constant: -16)
            let trailingContraint = NSLayoutConstraint(item: toastView, attribute: .leading, relatedBy: .equal, toItem: controller.view, attribute: .leading, multiplier: 1.0, constant: 16)
            controller.view.addConstraints([centerXContraint, centerYConstraint, leadingContraint, trailingContraint])
        case .bottom:
            let leading = NSLayoutConstraint(item: toastView, attribute: .leading, relatedBy: .equal, toItem: controller.view, attribute: .leading, multiplier: 1.0, constant: 16)
            let trailing = NSLayoutConstraint(item: toastView, attribute: .trailing, relatedBy: .equal, toItem: controller.view, attribute: .trailing, multiplier: 1.0, constant: -16)
            let bottom = NSLayoutConstraint(item: toastView, attribute: .bottom, relatedBy: .equal, toItem: controller.view.safeAreaLayoutGuide, attribute: .bottom, multiplier: 1.0, constant: -16)
            controller.view.addConstraints([leading, trailing, bottom])
        }
    }
    
    private func addGradience() {
        let gradientLayer = CAGradientLayer()
        let topColor = UIColor.blue
        let bottomColor = UIColor.blue
        gradientLayer.colors = [topColor, bottomColor]
        gradientLayer.frame = bounds
        layer.insertSublayer(gradientLayer, at: 0)
    }

}
