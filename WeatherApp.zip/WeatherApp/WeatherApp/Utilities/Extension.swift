//
//  Extension.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 02/12/21.
//

import UIKit

extension DateFormatter {
    
    static let serverDateFormat: DateFormatter = {
        let dateFormattor = DateFormatter()
        dateFormattor.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        dateFormattor.locale = Locale.current
        return dateFormattor
    }()
    
    static let detailDateFormat: DateFormatter = {
        let dateFormattor = DateFormatter()
        dateFormattor.dateFormat = "dd MMM yyyy"
        dateFormattor.locale = Locale.current
        return dateFormattor
    }()
    
    static let detailTimeFormat: DateFormatter = {
        let dateFormattor = DateFormatter()
        dateFormattor.dateFormat = "h:mm a"
        dateFormattor.locale = Locale.current
        return dateFormattor
    }()
    
}

extension String {
    func toDate() -> Date? {
        return DateFormatter.serverDateFormat.date(from: self)
    }
}

extension Date {
    func toString() -> String {
        return DateFormatter.serverDateFormat.string(from: self)
    }
    
    func toDetailString() -> String? {
        return DateFormatter.detailDateFormat.string(from: self)
    }
    
    func toDetailTimeString() -> String? {
        return DateFormatter.detailTimeFormat.string(from: self)
    }
}

extension Double {
    func round(to places: Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded() / divisor
    }
}

extension Array {

    func uniques<T: Hashable>(by keyPath: KeyPath<Element, T>) -> [Element] {
        return reduce([]) { result, element in
            let alreadyExists = (result.contains(where: { $0[keyPath: keyPath] == element[keyPath: keyPath] }))
            return alreadyExists ? result : result + [element]
        }
    }
}


extension UIImageView {
    
    func loadImage(from urlString: String?) {
        let encodedUrlString = urlString?.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        guard let urlString = encodedUrlString,
              let imageURL = URL(string: urlString) else {
            DispatchQueue.main.async {
                self.image = nil
            }
            return
        }
        
        let cache =  URLCache.shared
        let request = URLRequest(url: imageURL)
        
        DispatchQueue.global(qos: .userInitiated).async {
            if let data = cache.cachedResponse(for: request)?.data, let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    self.image = image
                }
            } else {
                URLSession.shared.dataTask(with: request, completionHandler: { (data, response, _) in
                    if let data = data, let response = response, ((response as? HTTPURLResponse)?.statusCode ?? 500) < 300, let image = UIImage(data: data) {
                        let cachedData = CachedURLResponse(response: response, data: data)
                        cache.storeCachedResponse(cachedData, for: request)
                        DispatchQueue.main.async {
                            self.image = image
                        }
                    } else {
                        DispatchQueue.main.async {
                            self.image = nil
                        }
                    }
                }).resume()
            }
        }
    }
}

extension UIColor {
    
    static var themeNavigationBarTint = {
        return UIColor(red: 0, green: 84/255, blue: 147/255, alpha: 1.0)
    }()
    
    static var themeNavigationTint = {
        return UIColor.white
    }()
}

