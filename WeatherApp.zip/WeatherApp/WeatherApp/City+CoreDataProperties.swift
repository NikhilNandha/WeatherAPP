//
//  City+CoreDataProperties.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 02/12/21.
//

import Foundation
import CoreData

extension City {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<City> {
        return NSFetchRequest<City>(entityName: "City")
    }
    
    @NSManaged public var name: String?
    @NSManaged public var picture: String?
    @NSManaged public var ofWeather: Weather?
}
