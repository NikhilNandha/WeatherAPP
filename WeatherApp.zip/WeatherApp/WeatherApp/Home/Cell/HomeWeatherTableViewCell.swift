//
//  HomeWeatherTableViewCell.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 02/12/21.
//

import UIKit

class HomeWeatherTableViewCell: UITableViewCell {

    @IBOutlet weak var cityNameLabel: UILabel!
    @IBOutlet weak var cityImageView: UIImageView!
    
    @IBOutlet weak var containerView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        containerView.layer.cornerRadius = 5.0
    }

    func configureCell(data: HomeModel.WeatherModel?) {
        cityNameLabel.text = data?.city?.name
        cityImageView.loadImage(from: data?.city?.picture)
    }
}
