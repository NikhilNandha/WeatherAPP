//
//  ViewController.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 02/12/21.
//

import UIKit
import CoreData

protocol HomeDisplayLogic: AnyObject {
    func fetchedResults(_ data: [HomeModel.WeatherModel]?, cities: [HomeModel.WeatherModel]?, error: NetworkError?)
}

class HomeViewController: UIViewController, HomeDisplayLogic {
    
    var interator: HomeBusinessLogic?
    var router: HomeRoutingLogic?
    var weatherData: [HomeModel.WeatherModel]?
    var cityData: [HomeModel.WeatherModel]?
    
    @IBOutlet weak var tableV: UITableView!
    var refreshControl: UIRefreshControl!
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setUp()
    }
    
    func setUp() {
        let homeInteractor = HomeInterator()
        let homePresenter = HomePresenter()
        let homeRouter = HomeRouter()
        homeRouter.viewController = self
        homePresenter.viewController = self
        homeInteractor.presenter = homePresenter
        router = homeRouter
        interator = homeInteractor
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = NSLocalizedString("home_title", comment: "")
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: NSLocalizedString("pull_to_referesh_message", comment: ""))
        refreshControl.addTarget(self, action: #selector(self.refresh(_:)), for: .valueChanged)
        tableV.addSubview(refreshControl)
        interator?.fetchWeatherData()
    }
    
    func fetchedResults(_ data: [HomeModel.WeatherModel]?, cities: [HomeModel.WeatherModel]?, error: NetworkError?) {
        switch error {
        case .noInternetError:
            ToastView.show(toastViewModal: ToastViewModal(withMessage: NSLocalizedString("no_internet_alert", comment: ""), position: ToastPosition.bottom, controller: self), isUpperImageHidden: true, callback: nil)
        default:
            break
        }
        refreshControl.endRefreshing()
        weatherData = data
        cityData = cities
        tableV.reloadData()
    }
    
    @objc func refresh(_ sender: AnyObject) {
        interator?.fetchWeatherData()
    }

}

extension HomeViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cityData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomeWeatherTableViewCell", for: indexPath) as! HomeWeatherTableViewCell
        cell.configureCell(data: cityData?[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        router?.routeToDetailsScreen(cityData: cityData?[indexPath.row], weatherData: weatherData)
    }
}
