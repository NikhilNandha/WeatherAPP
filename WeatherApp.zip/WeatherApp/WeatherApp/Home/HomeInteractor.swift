//
//  HomeInteractor.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 02/12/21.
//

import Foundation

protocol HomeBusinessLogic {
    func fetchWeatherData()
}

protocol HomeWorkerDataSource: AnyObject {
    func fetchWeatherData(complition: @escaping ([HomeModel.WeatherModel]?, NetworkError?) -> Void)
}

class HomeInterator: HomeBusinessLogic {
    
    var presenter: HomePresentationLogic?
    var worker: HomeWorkerDataSource?
    
    init() {
        let homeWorker = HomeWorker(persistentContainer: CoreDataStack.shared.persistentContainer)
        worker = homeWorker
    }
    
    func fetchWeatherData() {
        
        worker?.fetchWeatherData(complition: { [weak self] weatherData, error in
            //Creating Unique array with cities
            var cities = weatherData?.uniques(by: \.city?.name)
            
            //Sorting cities alphabetically
            cities = cities?.sorted { $0.city?.name ?? "" < $1.city?.name ?? "" }
            
            self?.presenter?.presentFetchResults(weatherData, cities: cities, error: error)
        })
    }
}
