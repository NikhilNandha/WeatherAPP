//
//  HomeModel.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 02/12/21.
//

import Foundation

struct HomeModel {
    
    struct WeatherModel: Codable {
        var date: String?
        var tempType: String?
        var temp: Double
        var city: WeatherCityModel?
        
        func celsiusTemp() -> Double {
            switch tempType {
            case "F":
                return ((temp - 32) / 1.8)
            case "K":
                return temp - 273.15
            default:
                return temp
            }
        }
    }
    
    struct WeatherCityModel: Codable {
        var name: String?
        var picture: String?
    }
}
