//
//  HomeRouter.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 03/12/21.
//

import UIKit

protocol HomeRoutingLogic {
    func routeToDetailsScreen(cityData: HomeModel.WeatherModel?, weatherData: [HomeModel.WeatherModel]?)
}

class HomeRouter: HomeRoutingLogic {
    
    weak var viewController: UIViewController?
    
    func routeToDetailsScreen(cityData: HomeModel.WeatherModel?, weatherData: [HomeModel.WeatherModel]?) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let weatherDetailsViewController = storyboard.instantiateViewController(withIdentifier: "WeatherDetailViewController") as! WeatherDetailViewController
        
        let interator = WeatherDetailInteractor()
        interator.weatherData = filteredWeatherCityData(cityData: cityData, weatherData: weatherData)
        let detailsPresenter = WeatherDetailPresenter()
        detailsPresenter.viewController = weatherDetailsViewController
        interator.presenter = detailsPresenter
        weatherDetailsViewController.detailsInterator = interator
        
        viewController?.navigationController?.pushViewController(weatherDetailsViewController, animated: true)
    }
    
    func filteredWeatherCityData(cityData: HomeModel.WeatherModel?, weatherData: [HomeModel.WeatherModel]?) -> [HomeModel.WeatherModel]? {
        let filteredData = weatherData?.filter({ $0.city?.name == cityData?.city?.name }).sorted(by: { $0.date?.toDate() ?? Date() < $1.date?.toDate() ?? Date() })
        
        return filteredData
    }
}
