//
//  HomePresenter.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 02/12/21.
//

import Foundation

protocol HomePresentationLogic: AnyObject {
    func presentFetchResults(_ data: [HomeModel.WeatherModel]?, cities: [HomeModel.WeatherModel]?, error: NetworkError?)
}

class HomePresenter: HomePresentationLogic {
    
    weak var viewController: HomeDisplayLogic?
    
    func presentFetchResults(_ data: [HomeModel.WeatherModel]?, cities: [HomeModel.WeatherModel]?, error: NetworkError?) {
        viewController?.fetchedResults(data, cities: cities, error: error)
    }
}
