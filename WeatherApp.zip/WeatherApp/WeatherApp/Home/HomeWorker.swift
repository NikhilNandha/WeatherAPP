//
//  HomeWorker.swift
//  WeatherApp
//
//  Created by Nikhil Nandha on 02/12/21.
//

import Foundation
import CoreData

class HomeWorker: NSObject {
    
    private let persistentContainer: NSPersistentContainer
    
    var viewContext: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    init(persistentContainer: NSPersistentContainer) {
        self.persistentContainer = persistentContainer
    }
    
    //MARK: - Core Data Methods -
    
    func syncWeatherData(weatherList: [HomeModel.WeatherModel], taskContext: NSManagedObjectContext) -> Bool {
        
        var successfull = false
        
        taskContext.performAndWait {
            
            let matchingNameRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Weather")
            let cityNames = weatherList.map { $0.city?.name }.compactMap { $0 }
            matchingNameRequest.predicate = NSPredicate(format: "city.name in %@", argumentArray: [cityNames])
            
            let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: matchingNameRequest)
            batchDeleteRequest.resultType = .resultTypeObjectIDs
            
            //// Execute the request to do batch delete and merge the changes to viewContext //
            do {
                let batchDeleteResult = try taskContext.execute(batchDeleteRequest) as? NSBatchDeleteResult
                
                if let deletedObjectIDs = batchDeleteResult?.result as? [NSManagedObjectID] {
                    NSManagedObjectContext.mergeChanges(fromRemoteContextSave: [NSDeletedObjectsKey: deletedObjectIDs],
                                                        into: [self.persistentContainer.viewContext])
                }
            } catch {
                print("Error: \(error)\nCould not batch delete existing records.")
                return
            }
            
            //// Create new records //
            for weatherObj in weatherList {
                
                guard let weather = NSEntityDescription.insertNewObject(forEntityName: "Weather", into: taskContext) as? Weather else {
                    print("Error: Failed to create a new Weather object!")
                    return
                }
                
                do {
                    try weather.update(with: weatherObj, context: taskContext)
                } catch {
                    print("Error: \(error)\nThe quake object will be deleted.")
                    taskContext.delete(weather)
                }
            }
            
            //// Save all the changes just made and reset the taskContext to free the cache //
            if taskContext.hasChanges {
                do {
                    try taskContext.save()
                } catch {
                    print("Error: \(error)\nCould not save Core Data context.")
                }
                
                //// Reset the context to clean up the cache and low the memory footprint //
                taskContext.reset()
            }
            successfull = true
        }
        return successfull
    }
    
    func fetchWeatherCoreDataEntites() -> [HomeModel.WeatherModel]? {
        let fetchReuqest = NSFetchRequest<Weather>(entityName: "Weather")
        do {
            let weatherData = try persistentContainer.viewContext.fetch(fetchReuqest)
            let weatherModelData: [HomeModel.WeatherModel]? = weatherData.map { (weather) -> HomeModel.WeatherModel in
                let city = HomeModel.WeatherCityModel(name: weather.city?.name, picture: weather.city?.picture)
                return HomeModel.WeatherModel(date: weather.date?.toString(), tempType: weather.tempType, temp: weather.temp, city: city)
            }
            return weatherModelData
        } catch let error {
            print("Error: \(error)\n Could not fetch Core Data context.")
            return nil
        }
    }
    
    //MARK: - Server API Methods -
    
    func fetchWeatherDataFromServer(completion: @escaping (Result<[HomeModel.WeatherModel], NetworkError>) -> Void) {
        
        let request = URLRequest(url: URL(string: ServerUrl + Endpoint.weather.rawValue)!)
        ServiceManager.shared.loadRequest(request: request, completion: completion)
    }
    
}

extension HomeWorker: HomeWorkerDataSource {
    
    
    func fetchWeatherData(complition: @escaping ([HomeModel.WeatherModel]?, NetworkError?) -> Void) {
        fetchWeatherDataFromServer { [weak self] result in
            switch result {
            case .success(let response):
                
                guard let taskContext = self?.persistentContainer.newBackgroundContext() else { return }
                taskContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
                taskContext.undoManager = nil
                let syncSuccess = self?.syncWeatherData(weatherList: response, taskContext: taskContext)
                
                complition(self?.fetchWeatherCoreDataEntites(), nil)
                print(">>>> Core data sync done: \(syncSuccess ?? false)")
            case .failure(let error):
                complition(self?.fetchWeatherCoreDataEntites(), error)
                print(">>>> Core data error")
            }
        }
    }
}
